from django.contrib import admin
from .models import Students,Parents,Course,Subject,Inscription,Teachers

admin.site.register(Students)
admin.site.register(Parents)
admin.site.register(Course)
admin.site.register(Subject)
admin.site.register(Inscription)
admin.site.register(Teachers)



